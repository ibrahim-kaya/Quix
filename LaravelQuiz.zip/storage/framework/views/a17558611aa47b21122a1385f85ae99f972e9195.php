<div>
    <input wire:model="title" type="title"><br>

    <button wire:click="test()">Dene</button>
</div>
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/livewire/sorular.blade.php ENDPATH**/ ?>