 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Quiz <?php $__env->endSlot(); ?>

    <?php if(\App\Models\Cevap::where('userid', Auth::user()->id)->get()->where('soru_id', \App\Models\Quiz::find($data['quiz']->id)->sorular->first()->id)->count()): ?>
        <h1 class="text-xl font-bold"><?php echo e($data['quiz']->baslik); ?></h1>
        <h1 class="text-lg"><?php echo e($data['quiz']->aciklama); ?></h1>

        <p>Çözüldüğü tarih: <?php echo e(\App\Models\Cevap::where('userid', Auth::user()->id)->get()->where('soru_id', \App\Models\Quiz::find($data['quiz']->id)->sorular->first()->id)->first()->created_at); ?></p>

        <a href="<?php echo e(route('sonuc_Goster', [Auth::user()->id, $data['quiz']->uniqueid])); ?>"><button type="submit" class="btn btn--primary w-full lg:w-1/2 font-bold"><i class="fas fa-check-circle"></i> Sonuçları Göster</button></a>
    <?php else: ?>
        <h1 class="text-xl font-bold"><?php echo e($data['quiz']->baslik); ?></h1>
        <h1 class="text-lg"><?php echo e($data['quiz']->aciklama); ?></h1>

        <a href="<?php echo e(route('quiz.show', $data['quiz']->uniqueid)); ?>"><button class="btn btn--primary w-full lg:w-1/2 font-bold"><i class="fas fa-check-circle"></i> Quize Başla</button></a>
    <?php endif; ?>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/quiz/onizleme.blade.php ENDPATH**/ ?>