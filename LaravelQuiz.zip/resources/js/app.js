require('./bootstrap');

require('alpinejs');
require('jquery');

import $ from 'jquery'
window.jQuery=$;
window.$ = $;
