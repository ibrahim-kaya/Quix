<x-app-layout>
    <x-slot name="header">Anasayfa</x-slot>

    <x-jet-welcome />

</x-app-layout>
