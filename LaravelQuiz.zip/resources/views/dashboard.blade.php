<x-app-layout>
    <x-slot name="header">Anasayfa</x-slot>

    <div class="m-20">
        <h1 class="text-2xl font-bold text-gray-600 text-shadow-md m-3">Burası yakında anasayfa olacak...</h1>
        <p>Şimdilik yukarıdaki menüden <b>Quizler</b> sayfasını kullan.</p>
    </div>

</x-app-layout>
