<?php return array (
  'modal-wire' => 'App\\Http\\Livewire\\ModalWire',
  'quizlerim' => 'App\\Http\\Livewire\\Quizlerim',
);