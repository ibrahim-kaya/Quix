<?php return array (
  'quizlerim' => 'App\\Http\\Livewire\\Quizlerim',
  'sorular' => 'App\\Http\\Livewire\\Sorular',
);