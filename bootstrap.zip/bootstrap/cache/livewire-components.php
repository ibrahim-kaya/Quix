<?php return array (
  'edit-soru' => 'App\\Http\\Livewire\\EditSoru',
  'post-soru' => 'App\\Http\\Livewire\\PostSoru',
  'quizlerim' => 'App\\Http\\Livewire\\Quizlerim',
  'sorular' => 'App\\Http\\Livewire\\Sorular',
);