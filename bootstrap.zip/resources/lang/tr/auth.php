<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Kimlik Doğrulama
    |--------------------------------------------------------------------------
    |
    | Aşağıdaki metinler kimlik doğrulama (giriş) sırasında kullanıcılara
    | gösterilebilecek mesajlardır. Bu metinleri uygulamanızın
    | gereksinimlerine göre düzenlemekte özgürsünüz.
    |
    */

    'failed' => 'Girilmiş olan kullanıcı verileri sistemdekiler ile eşleşmemektedir.',
    'password' => 'Yanlış şifre girdin!',
    'throttle' => 'Çok fazla oturum açma girişiminde bulundun. Lütfen :seconds saniye sonra tekrar dene.',
];
