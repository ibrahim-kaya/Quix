<x-app-layout>
    <x-slot name="header">Quizlerim</x-slot>

    @livewire('quizlerim')

</x-app-layout>
