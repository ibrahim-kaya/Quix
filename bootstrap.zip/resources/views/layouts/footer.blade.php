<footer class="mt-4 border-t py-3 text-xs text-gray-500 text-center leading-5 bg-gray-100">
    <a href="{{ route('terms.show') }}">Kullanım Şartları</a> · <a href="{{ route('policy.show') }}">Gizlilik Politikası</a> · <a href="{{ route('credits_1') }}">Katkıda Bulunanlar</a><br>
    <a href="">Twitter</a> · <a href="">Instagram</a> · <a href="">Facebook</a><br>
    © 2021 <a href="{{ config('app.url') }}">{{ config('app.name') }}</a>
</footer>
