 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Düellolarım <?php $__env->endSlot(); ?>

    <div class="sm:flex bg-gray-100 border border-gray-200 overflow-x-auto">
        <a href="<?php echo e(route('duellolarim')); ?>">
            <div class="border-b sm:border-b-0 sm:border-r border-gray-300 py-1 sm:py-3 px-2 px-1">
                Tamamlananlar <b class="text-gray-500">(<?php echo e(count($data['biten'])); ?>)</b>
            </div>
        </a>
        <div class="bg-gray-300 border-b sm:border-b-0 sm:border-r border-gray-300 py-1 sm:py-3 px-2 px-1">
            Devam Edenler <b class="text-gray-500">(<?php echo e(count($data['devameden']) + $data['kabulbekleyen']->count()); ?>)</b>
        </div>
        <a href="?durum=istekler">
            <div class="sm:border-r border-gray-300 py-1 sm:py-3 px-2 px-1">
                İstekler <b class="text-red-600">(<?php echo e($data['istekler']->count()); ?>)</b>
            </div>
        </a>
    </div>
    <div class="mt-4 sm:m-5">
        <h1 class="text-xl font-bold">Devam Eden Düellolar</h1>
        <div class="mt-2 sm:p-3 bg-gray-100 border border-gray-200 rounded-md">
            <?php $__currentLoopData = $data['devameden']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duello): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $gonderen = \App\Models\User::find($duello->olusturan_id);
                $giden = \App\Models\User::find($duello->rakip_id);
                ?>
                <div
                    class="flex flex-wrap items-center justify-between bg-blue-100 border border-blue-200 hover:bg-blue-200 p-2 transition <?php if(!$loop->first): ?> border-t-0 <?php endif; ?>">
                    <div>
                        <?php if($gonderen->id == \Illuminate\Support\Facades\Auth::user()->id): ?>
                            <h1 class="text-green-600 font-bold text-xl"><i class="fas fa-angle-double-right"></i>
                                Gönderilen</h1>
                            <p>Kime: <a href="<?php echo e(route('profil', $giden->name)); ?>"
                                        class="text-blue-500 font-bold"><?php echo e($giden->name); ?></a>
                        <?php else: ?>
                            <h1 class="text-yellow-600 font-bold text-xl"><i class="fas fa-angle-double-left"></i> Gelen
                            </h1>
                            <p>Kimden: <a href="<?php echo e(route('profil', $gonderen->name)); ?>"
                                          class="text-blue-500 font-bold"><?php echo e($gonderen->name); ?></a>
                                <?php endif; ?></p>
                            <p>Kategori:
                                <b><?php echo e($data['kategoriler']->where('link', $duello->kategori)->first()->isim); ?></b></p>
                            <p>Durum: <b class="text-yellow-600">Sonuç Bekleniyor...</b>
                            </p>
                    </div>
                    <a href="<?php echo e(route('duello_onizleme', $duello->uniqueid)); ?>">
                        <button class="btn--primary">Gör</button>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $data['kabulbekleyen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duello): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $gonderen = \App\Models\User::find($duello->olusturan_id);
                $giden = \App\Models\User::find($duello->rakip_id);
                ?>
                <div
                    class="flex flex-wrap items-center justify-between bg-blue-100 border border-blue-200 hover:bg-blue-200 p-2 transition <?php if(!$loop->first): ?> border-t-0 <?php endif; ?>">
                    <div>
                        <?php if($gonderen->id == \Illuminate\Support\Facades\Auth::user()->id): ?>
                            <h1 class="text-green-600 font-bold text-xl"><i class="fas fa-angle-double-right"></i>
                                Gönderilen</h1>
                            <p>Kime: <a href="<?php echo e(route('profil', $giden->name)); ?>"
                                        class="text-blue-500 font-bold"><?php echo e($giden->name); ?></a>
                        <?php else: ?>
                            <h1 class="text-yellow-600 font-bold text-xl"><i class="fas fa-angle-double-left"></i> Gelen
                            </h1>
                            <p>Kimden: <a href="<?php echo e(route('profil', $gonderen->name)); ?>"
                                          class="text-blue-500 font-bold"><?php echo e($gonderen->name); ?></a>
                                <?php endif; ?></p>
                            <p>Kategori:
                                <b><?php echo e($data['kategoriler']->where('link', $duello->kategori)->first()->isim); ?></b></p>
                            <p>Durum: <b class="text-yellow-600">Henüz Kabul Edilmedi...</b>
                            </p>
                    </div>
                    <a href="<?php echo e(route('duello_onizleme', $duello->uniqueid)); ?>">
                        <button class="btn--primary">Gör</button>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(!count($data['devameden']) && !count($data['kabulbekleyen'])): ?>
                    <div class="text-center text-gray-600 w-full p-10 border border-gray-200 rounded-md bg-gray-100"><p>Devam eden düello bulunamadı.</p></div>
                <?php endif; ?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/duello/duellolarim/tamamlanmayan.blade.php ENDPATH**/ ?>