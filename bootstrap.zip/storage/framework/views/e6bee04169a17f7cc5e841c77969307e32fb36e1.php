<a href="/">
    <img src="/storage/img/logo.png" alt="<?php echo e(config('app.name')); ?>" class="w-24 mt-5">
</a>
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\vendor\laravel\jetstream\src/../resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>