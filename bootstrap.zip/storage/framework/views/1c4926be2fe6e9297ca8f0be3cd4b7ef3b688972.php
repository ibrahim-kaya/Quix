 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Düello <?php $__env->endSlot(); ?>

    <div class="flex flex-wrap w-full justify-center bg-gray-100 text-center p-2 mb-5 border-b border-gray-200">
        <h1 class="text-2xl font-bold text-red-600">Yanlış Cevap!</h1>
        <div class="w-full"></div>
        <img src="/storage/img/duello/yanlis.webp" alt="" class="h-36 rounded-md my-2">
        <div class="w-full"></div>
        <p class="text-red-600">Doğru Cevap!</p>
    </div>
    <p class="text-center mb-2">Kalan Süre: <b class="text-xl">00:45</b></p>


    <form method="post" action="" class="px-5">
        <?php echo csrf_field(); ?>
        <h1 class="text-lg pb-3 font-bold">Soru 1: blablalbablablalbablablalbablablalbablablalbablablalbablablalbablablalbablablalbablablalbablablalbablablalba</h1>

        <input type="radio" id="cevap-1" name="cevap" class="hidden secenek" value="cevap1">
        <label for="cevap-1"><span class="text-lg font-bold">a)</span> blablalba</label><br>

        <input type="radio" id="cevap-2" name="cevap" class="hidden secenek" value="cevap2">
        <label for="cevap-2"><span class="text-lg font-bold">b)</span> blablalba</label><br>

        <input type="radio" id="cevap-3" name="cevap" class="hidden secenek" value="cevap3">
        <label for="cevap-3"><span class="text-lg font-bold">c)</span> blablalba</label><br>

        <input type="radio" id="cevap-4" name="cevap" class="hidden secenek" value="cevap4">
        <label for="cevap-4"><span class="text-lg font-bold">d)</span> blablalba</label><br>
        <br>
        <button type="submit" class="btn btn--primary w-full lg:w-1/2 font-bold"><i class="fas fa-check-circle"></i> Onayla</button>
    </form>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/duello/cop.blade.php ENDPATH**/ ?>