<div>
    <div class="flex flex-col md:flex-row m-5">
        <div class="border border-gray-300 rounded-md p-5">
            <div>
                <div>
                    <img class="w-16 h-16 rounded-full"
                         src="<?php echo e($data['user']['profile_photo_url']); ?>"
                         alt="<?php echo e($data['user']['name']); ?>"/>
                    <?php echo e($data['user']['name']); ?>

                </div>
                <div class="border-t border-gray-300 mt-5 pt-5">
                    <button wire:click="Show(1)" class="btn--primary">Çözülen quizler</button>
                </div>
            </div>
        </div>
        <div>
            <?php echo e($flow); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/livewire/profil.blade.php ENDPATH**/ ?>