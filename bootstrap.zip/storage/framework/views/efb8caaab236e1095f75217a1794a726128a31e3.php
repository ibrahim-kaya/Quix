<div>
    <div class="px-5 py-3 max-h-96 md:max-h-full overflow-y-scroll md:overflow-hidden">
        <div>
            <label><b>Soruyu yaz:</b></label><br>
            <textarea class="rounded-md mb-4" name="soru"></textarea><br>
            <label><b>Soru resmi (opsiyonel):</b></label><br>
            <input type="file" class="rounded-md w-full" name="resim">
            <div class="flex flex-col lg:flex-row mt-4">
                <div class="w-full lg:w-1/2 lg:pr-5">
                    <label><b>A şıkkı:</b></label><br>
                    <input type="text" name="cevap1" class="rounded-md w-full p-1">
                    <div class="mb-4"><input id="a" type="radio" name="dogru_cevap"
                                             value="cevap1"><label
                            for="a" class="text-sm">Doğru Şık</label></div>
                    <label><b>B şıkkı:</b></label><br>
                    <input type="text" name="cevap2" class="rounded-md w-full p-1">
                    <div class="mb-4"><input id="b" type="radio" name="dogru_cevap"
                                             value="cevap2"><label
                            for="b" class="text-sm">Doğru Şık</label></div>
                </div>
                <div class="w-full lg:w-1/2">
                    <label><b>C şıkkı:</b></label><br>
                    <input type="text" name="cevap3" class="rounded-md w-full p-1">
                    <div class="mb-4"><input id="c" type="radio" name="dogru_cevap"
                                             value="cevap3"><label
                            for="c" class="text-sm">Doğru Şık</label></div>
                    <label><b>D şıkkı:</b></label><br>
                    <input type="text" name="cevap4" class="rounded-md w-full p-1">
                    <div class="mb-4">
                        <input id="d" type="radio" name="dogru_cevap" value="cevap4"><label for="d" class="text-sm">Doğru
                            Şık</label></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/livewire/edit-soru.blade.php ENDPATH**/ ?>