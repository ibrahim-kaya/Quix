<?php if(is_numeric($user->id)): ?>
    <a href="<?php echo e(route('profil', $user->name)); ?>" title="Profile git" class="w-max">
        <?php endif; ?>
        <div
            class="flex items-center font-bold <?php echo e($bg); ?> border <?php echo e($border); ?> w-max p-1.5 px-4 rounded-xl mt-1 cursor-pointer hover:bg-gray-200 transition">
            <img class="inline w-10 h-10 rounded-full"
                 src="<?php echo e($user->profile_photo_url); ?>"
                 alt="<?php echo e($user->name); ?>"/>
            <p class="ml-2 <?php if(is_numeric($user->id)): ?> text-blue-500 <?php else: ?> text-gray-600 <?php endif; ?>"><?php echo e($user->name); ?></p>
        </div>
        <?php if(is_numeric($user->id)): ?>
    </a>
<?php endif; ?>
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/quiz/templates/user-card.blade.php ENDPATH**/ ?>