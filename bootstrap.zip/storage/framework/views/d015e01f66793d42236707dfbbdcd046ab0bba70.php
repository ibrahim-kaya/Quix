 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Düellolarım <?php $__env->endSlot(); ?>

    <div class="mt-4 sm:m-5">
        <h1 class="ml-2 text-2xl font-bold">Düello İstekleri</h1>

        <div class="mt-5 sm:p-3 bg-gray-100 border border-gray-200 rounded-md">
            <?php $__currentLoopData = $data['duellolar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duello): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $gonderen = \App\Models\User::find($duello->olusturan_id) ?>
                    <div class="flex flex-wrap bg-blue-100 border border-blue-200 hover:bg-blue-200 p-2 transition <?php if(!$loop->first): ?> border-t-0 <?php endif; ?>">
                        <p>Gönderen: <a href="<?php echo e(route('profil', $gonderen->id)); ?>" class="text-blue-500 font-bold"><?php echo e($gonderen->name); ?></a> - Kategori: <b><?php echo e($data['kategoriler']->where('link', $duello->kategori)->first()->isim); ?></b></p>
                        <div class="w-full"></div>
                        <a href="<?php echo e(route('duello_onizleme', $duello->uniqueid)); ?>"><button class="btn--primary">Gör</button></a>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/duello/duellolarim.blade.php ENDPATH**/ ?>