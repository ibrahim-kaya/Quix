<footer class="mt-4 border-t py-3 text-xs text-gray-500 text-center leading-5 bg-gray-100">
    <a href="<?php echo e(route('terms.show')); ?>">Kullanım Şartları</a> · <a href="<?php echo e(route('policy.show')); ?>">Gizlilik Politikası</a> · <a href="<?php echo e(route('credits_1')); ?>">Katkıda Bulunanlar</a><br>
    <a href="">Twitter</a> · <a href="">Instagram</a> · <a href="">Facebook</a><br>
    © 2021 <a href="<?php echo e(config('app.url')); ?>"><?php echo e(config('app.name')); ?></a>
</footer>
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/layouts/footer.blade.php ENDPATH**/ ?>