<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.credits', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/credits/sec-3.blade.php ENDPATH**/ ?>