 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Düello <?php $__env->endSlot(); ?>

    <?php if($data['mesaj']): ?>
        <div class="flex flex-wrap w-full justify-center bg-gray-100 text-center p-2 mb-5 border-b border-gray-200">
            <h1 class="text-2xl font-bold <?php if($data['puan']): ?> text-green-600 <?php else: ?> text-red-600 <?php endif; ?>"><?php echo e($data['mesaj']); ?></h1>
            <div class="w-full"></div>
            <img src="<?php if($data['puan']): ?> /storage/img/duello/dogru.webp <?php else: ?> /storage/img/duello/yanlis.webp <?php endif; ?>"
                 alt="" class="h-36 rounded-md my-2">
            <div class="w-full"></div>
            <p class="<?php if($data['puan']): ?> text-green-600 <?php else: ?> text-red-600 <?php endif; ?>">+<?php echo e($data['puan']); ?> Puan</p>
        </div>
    <?php endif; ?>

    <p class="text-center mb-2">Kalan Süre: <b id="sayac" class="text-xl">00:45</b></p>

    <form method="post" action="" class="px-5">
        <?php echo csrf_field(); ?>
        <h1 class="text-lg pb-3 font-bold">Soru <?php echo e($data['index']); ?>: <?php echo e($data['soru']->soru); ?></h1>

        <?php if($data['soru']->resim): ?>
            <img src="<?php echo e($data['soru']->resim); ?>" alt="" class="max-h-64 pb-3">
        <?php endif; ?>

        <input type="radio" id="cevap-1" name="cevap" class="hidden secenek" value="cevap1">
        <label for="cevap-1"><span class="text-lg font-bold">a)</span> <?php echo e($data['soru']->cevap1); ?></label><br>

        <input type="radio" id="cevap-2" name="cevap" class="hidden secenek" value="cevap2">
        <label for="cevap-2"><span class="text-lg font-bold">b)</span> <?php echo e($data['soru']->cevap2); ?></label><br>

        <?php if($data['soru']->cevap3): ?> <input type="radio" id="cevap-3" name="cevap" class="hidden secenek" value="cevap3">
        <label for="cevap-3"><span class="text-lg font-bold">c)</span> <?php echo e($data['soru']->cevap3); ?></label><br> <?php endif; ?>

        <?php if($data['soru']->cevap4): ?> <input type="radio" id="cevap-4" name="cevap" class="hidden secenek" value="cevap4">
        <label for="cevap-4"><span class="text-lg font-bold">d)</span> <?php echo e($data['soru']->cevap4); ?></label><br> <?php endif; ?>
        <br>
        <button type="submit" class="btn btn--primary w-full lg:w-1/2 font-bold"><i class="fas fa-check-circle"></i>
            Onayla
        </button>
        <br>
        <p class="text-sm text-gray-600 mt-10"> Soruyu ekleyen: <a href="<?php echo e(route('profil', $data['soru_user']->name)); ?>" class="text-blue-500 font-bold"><?php echo e($data['soru_user']->name); ?></a></p>
    </form>

    <script>
        setTimeout(
            function () {
                const form = document.createElement('form');
                form.method = 'post';
                form.action = '';


                const hiddenField = document.createElement('input');
                hiddenField.type = 'hidden';
                hiddenField.name = '_token';
                hiddenField.value = '<?php echo e(csrf_token()); ?>';

                form.appendChild(hiddenField);


                document.body.appendChild(form);
                form.submit();
            }, 45000);

        const countDownDate = new Date();
        countDownDate.setSeconds(countDownDate.getSeconds() + 45);

        const x = setInterval(function () {
            const now = new Date().getTime();
            const distance = countDownDate - now;
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            document.getElementById("sayac").innerHTML = "00:" + seconds;
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("sayac").innerHTML = "SÜRE DOLDU";
            }
        }, 1000);

    </script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/duello/test.blade.php ENDPATH**/ ?>