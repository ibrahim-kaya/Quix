 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="/css/profil.css">

     <?php $__env->slot('header'); ?> Profil <?php $__env->endSlot(); ?>

    <div>
        <div class="p-5">
            <div class="flex items-center border-b border-gray-200 pb-5">
                <img class="inline w-16 h-16 md:w-24 md:h-24 rounded-full"
                     src="<?php echo e($data['user']->profile_photo_url); ?>"
                     alt="<?php echo e($data['user']->name); ?>"/>
                <p class="ml-5 text-lg font-bold"><?php echo e($data['user']->name); ?></p>
            </div>

        </div>

        <div class="tabs">
            <div class="tab-baslik">
                <div class="aktif">
                    <p>Oluşturdukları</p>
                   <?php if($data['quizler']->count()): ?> <p style="margin: 0; font-size: 9pt;"><?php echo e($data['quizler']->count()); ?></p> <?php endif; ?>
                </div>
                <div>
                    <p>Çözdükleri</p>
                    <?php if($data['cozulenler']->count()): ?> <p style="margin: 0; font-size: 9pt;"><?php echo e($data['cozulenler']->count()); ?></p> <?php endif; ?>
                </div>
            </div>
            <div class="tab-bg"></div>
            <div class="tab-indicator"></div>
        </div>

        <div>
            <div class="posts flex flex-wrap mx-1 overflow-hidden">
                <?php $__empty_1 = true; $__currentLoopData = $data['quizler']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('quiz.templates.quiz-box', ['quiz' => $quiz, 'kategori' => $data['kategoriler']->where('link', $quiz->kategori)->first()->isim, 'userid' => $data['user']->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-gray-600 w-full p-10 border border-gray-200 rounded-md bg-gray-100"><p>Bu kullanıcı hiç Quiz oluşturmamış.</p></div>
                <?php endif; ?>
            </div>
            <div class="posts flex flex-wrap mx-1 overflow-hidden" style="opacity: 0; height: 0;">

                <?php $__empty_1 = true; $__currentLoopData = $data['cozulenler']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('quiz.templates.quiz-box', ['quiz' => $quiz, 'kategori' => $data['kategoriler']->where('link', $quiz->kategori)->first()->isim, 'userid' => $data['user']->id, 'puan' => $quiz->getUserScore($data['user']->id)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-gray-600 w-full p-10 border border-gray-200 rounded-md bg-gray-100"><p>Bu kullanıcı hiç Quiz çözmemiş.</p></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="/js/profil.js"></script>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/quiz/profil/profil.blade.php ENDPATH**/ ?>