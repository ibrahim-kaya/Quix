 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> Katkıda Bulunanlar <?php $__env->endSlot(); ?>

    <style>
        a {
            color: cornflowerblue;
        }

        b {
            color: #606f7b;
        }

        li {
            margin-left: 20px;
            margin-top: 5px;
            font-size: 14px;
        }
    </style>

    <div class="flex flex-col sm:flex-row justify-around bg-gray-200 text-center">
        <a class="<?php if(Route::currentRouteName() === 'credits_1'): ?> c_aktif" <?php else: ?> c_pasif" href="<?php echo e(route('credits_1')); ?>

        " <?php endif; ?> style="border-left: 0;">
        <div>Kullanılan Görseller</div>
        </a>
        <a class="<?php if(Route::currentRouteName() === 'credits_2'): ?> c_aktif" <?php else: ?> c_pasif" href="<?php echo e(route('credits_2')); ?>

        " <?php endif; ?>>
        <div>Sec 2</div>
        </a>
        <a class="<?php if(Route::currentRouteName() === 'credits_3'): ?> c_aktif" <?php else: ?> c_pasif" href="<?php echo e(route('credits_3')); ?>

        " <?php endif; ?>>
        <div>Sec 3</div>
        </a>
    </div>

    <div class="p-3 mt-3">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\XpDeviL\Desktop\Projeler\LaravelQuiz\resources\views/layouts/credits.blade.php ENDPATH**/ ?>